package com.joon.c.board;

import com.joon.c.board.data.Data;
import com.joon.c.board.data.Post;
import com.joon.util.Ci;
import com.joon.util.Cw;

public class ProductMenuUpdate {
	static void run() {
		Cw.wn("[업데이트]");
		String cmd = Ci.r("수정할 글 번호를 입력하세요");
		for (Post p : Data.posts) {
			if (cmd.equals(p.instanceNo + "")) {
				String content = Ci.rl("수정 할 글 내용을 입력하세요");
				p.content = content;
				Cw.wn("ㅅㄱ");
			}
		}
	}
}