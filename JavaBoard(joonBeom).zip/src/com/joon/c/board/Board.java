package com.joon.c.board;

import com.joon.c.board.data.Data;
import com.joon.c.board.display.Display;

public class Board {
	public static final String TITLE = "게시판";
	public void run() {
		Data.loadData();
		Display.title();
		ProductMenu.run();
	}
}
