package com.joon.c.board;

import com.joon.c.board.display.Display;
import com.joon.util.Ci;
import com.joon.util.Cw;

public class ProductMenu {
	static void run() {
		Display.menuMain();
		loop_a:
		while(true) {
			String cmd = Ci.r("번호를 작성해주세요");
			switch(cmd) {
			case "1":	
				ProductMenuList.run();
				break;
			case "2":	
				ProductMenuRead.run();
				break;
			case "3":	
				ProductMenuWrite.run();
				break;
			case "4":	
				ProductMenuDel.run();
				break;
			case "5":	
				ProductMenuUpdate.run();
				break;
			case "e":
				System.out.println("프로그램 종료");
				break loop_a;
			default:
				Cw.wn("[1. 2. 3. 4. 5. e. 번을 눌러주세요]");
				break;
			}
		}
	}

}
