package com.joon.c.board;

import com.joon.c.board.data.Data;
import com.joon.c.board.data.Post;
import com.joon.util.Ci;
import com.joon.util.Cw;

public class ProductMenuRead {
	static void run() {
		Cw.wn("[읽기]");
		String cmd = Ci.r("읽을 글 번호");
		for(Post p:Data.posts) {
			if(cmd.equals(p.instanceNo+"")) {
				p.infoForRead();
			}
			else {
				System.out.println("글이 없습니다");
				return;
			}
		}		
	}

}
