package com.joon.c.board.display;

import com.joon.c.board.Board;
import com.joon.util.Cw;

public class Display {
	public static void title() {
		Cw.line();
		Cw.dot();
		Cw.space(15);
		Cw.w(Board.TITLE);
		Cw.space(15);
		Cw.dot();
		Cw.wn();
		Cw.line();
	}
	public static void menuMain() {
		Cw.w("[1. 글 리스트 2. 글 읽기 3. 글 쓰기 4. 글 삭제 5. 글 수정 e. 종료]");
		Cw.wn();
	}

}
