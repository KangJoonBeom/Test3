package com.joon.c.board;

import com.joon.c.board.data.Data;
import com.joon.c.board.data.Post;
import com.joon.util.Cw;

public class ProductMenuList {
	static void run() {
		Cw.wn("[글 리스트]");
		for(Post p:Data.posts) {
			p.infoForList();
		}
	}

}
